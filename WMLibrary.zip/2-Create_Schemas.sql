/* Purpose Create My WMLbrary Database Schemas
Script Date: April 04 2019
Developed By: Aaron Graham, Wu Guo, Hang Ruan, Aleksander Uher */

use WMLibrary;
go

create schema Persons authorization dbo;
go

create schema Records authorization dbo;
go

create schema Books authorization dbo;
go
